﻿// See https://aka.ms/new-console-template for more information



using proxydesignpattern;

IService serviceObj = new ActualService();
IService proxy = new ProxyService(serviceObj);

proxy.SignIn(12);
proxy.SignIn(21);

