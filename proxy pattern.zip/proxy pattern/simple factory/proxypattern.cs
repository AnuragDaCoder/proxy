﻿namespace proxydesignpattern
{
    interface IService
    {
        void SignIn(int age);
    }

    public class ActualService : IService
    {
        public void SignIn(int age)
        {
            Console.WriteLine($"You have signed in. Your age is {age}");
        }
    }

    class ProxyService : IService
    {
        private readonly IService _service;

        public ProxyService(IService service)
        {
            _service = service;
        }

        public void SignIn(int age)
        {
            if(age < 18)
            {
                Console.WriteLine("You are too young!!");
            }
            else
            {
                _service.SignIn(age);
            }
        }
    }
}
